<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("UTHEME_MENU_L1", "Beállít");
define("UTHEME_MENU_L2", "Válasszon nyelvet");
define("UTHEME_MENU_L3", "táblák");

define("LAN_UMENU_THEME_1", "Theme kiválasztás");
define("LAN_UMENU_THEME_2", "Theme kiválasztása");
define("LAN_UMENU_THEME_3", "felhasználók:");
define("LAN_UMENU_THEME_4", "Azon theme-k engedélyezése, melyeket a felhasználók kiválaszthatnak");
define("LAN_UMENU_THEME_5", "Frissítés");
define("LAN_UMENU_THEME_6", "A felhasználók rendelkezésére álló theme-k");
define("LAN_UMENU_THEME_7", "Csoport, amely theme-ket tud választani");
define("LAN_UMENU_THEME_8", "Engedélyezett témák:");
define("LAN_UMENU_THEME_9", "Csoport, amely theme-ket tud választani:");
