<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_AL_GSMAP_01", "Webhelylinkek importálása");
define("LAN_AL_GSMAP_02", "Oldaltérkép link törölve");
define("LAN_AL_GSMAP_03", "Oldaltérkép link hozzáadva");
define("LAN_AL_GSMAP_04", "Oldaltérkép link frissítve");
