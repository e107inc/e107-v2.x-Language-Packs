<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("GSLAN_1", "Főmenü link");
define("GSLAN_2", "Importálás?");

define("GSLAN_7", "Linkek importálása");
define("GSLAN_8", "Importálás:");
define("GSLAN_9", "Prioritás");
define("GSLAN_10", "Gyakoriság");
define("GSLAN_11", "mindig");
define("GSLAN_12", "óránkénti");
define("GSLAN_13", "napi");
define("GSLAN_14", "heti");
define("GSLAN_15", "havi");
define("GSLAN_16", "évente");

define("GSLAN_18", "Linkek importálása");
define("GSLAN_20", "Listázás");
define("GSLAN_21", "Előírások");
define("GSLAN_22", "Új bejegyzés létrehozása");
define("GSLAN_23", "Importálás");
define("GSLAN_24", "Google Oldaltérkép bejegyzések");
define("GSLAN_27", "Utolsó módosítás");
define("GSLAN_28", "Gyakoriság");
define("GSLAN_29", "Google Oldaltérkép beállítása");

define("GSLAN_32", "Hogyan használd a Google Oldaltérképet");
define("GSLAN_33", "GSiteMap Előírások");
define("GSLAN_34", "Először, hozz létre egy linket, melyet meg szeretnél jeleníteni az oldaltérképen. A legtöbb linket importálnod kell az 'Importálás' gomb megnyomásának segítségével");
define("GSLAN_35", "Ha kiválasztottad a megfelelő linkeket, akkor nyomd meg az 'Importálás' gombot, majd ellenőrizd a művelet helyességét");
define("GSLAN_36", "Egyéni linket is létrehozhatsz manuálisan az 'Új bejegyzés létrehozása' gomb megnyomásával");
define("GSLAN_37", "Ha már rendelkezel néhány bejegyzéssel, akkor lépj a [URL] oldalra és add meg a következő URL-t: <b>'. SITEURL.' gsitemap.php</b> - ha ez az url nem jelenik meg megfelelően, akkor javítani kell az oldalad url-jét az admin -> beállítások felületen");
define("GSLAN_38", "További információkhoz lépj a [URL] oldalra.");
define("GSLAN_39", "Nem található link az oldaltérképben - szeretnél importálni linkeket?");
