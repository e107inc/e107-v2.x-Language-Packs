<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("TRACKBACK_L7", "Trackback aktiválása");
define("TRACKBACK_L8", "Trackback URL szöveg");
define("TRACKBACK_L10", "Trackback beállítások");
define("TRACKBACK_L11", "Trackback cím a hírhez:");
define("TRACKBACK_L12", "Nincsenek trackback-ek");
define("TRACKBACK_L13", "Trackback-ek moderálása");
define("TRACKBACK_L16", "Trackback");
