<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PLUGIN_TRACKBACK_NAME", "Trackback");
define("LAN_PLUGIN_TRACKBACK_DESCRIPTION", "Ez a plugin engedélyezi a trackback használatát a hír üzenetekben.");
