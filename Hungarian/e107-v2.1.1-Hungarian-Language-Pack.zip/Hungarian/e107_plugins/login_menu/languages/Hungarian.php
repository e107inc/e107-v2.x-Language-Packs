<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_LOGINMENU_1", "Felhasználónév: ");
define("LAN_LOGINMENU_2", "Jelszó: ");
define("LAN_LOGINMENU_3", "Regisztráció");
define("LAN_LOGINMENU_4", "Elfelejtett jelszó?");
define("LAN_LOGINMENU_5", "Üdvözlet");
define("LAN_LOGINMENU_6", "Adatok megjegyzése");
define("LAN_LOGINMENU_7", "Egyedi azonosító nem felismerhető (valószínűleg hibás cookie).<br /><a href=\"".e_BASE."index.php?logout\">Kattints ide</a> a cookie megsemmisítéséhez.");
define("LAN_LOGINMENU_9", "Bejelentkezési hiba");
define("LAN_LOGINMENU_10", "Karbantartás üzemmód bekapcsolva - A normál felhasználók csak a sitedown.php -t érhetik el. Kikapcsolható az admin részlegben");
define("LAN_LOGINMENU_11", "Admin");
define("LAN_LOGINMENU_13", "Profil");
define("LAN_LOGINMENU_14", "új hír");
define("LAN_LOGINMENU_15", "új hír");
define("LAN_LOGINMENU_16", "új chatbox üzenet");
define("LAN_LOGINMENU_17", "új chatbox üzenet");
define("LAN_LOGINMENU_18", "új hozzászólás");
define("LAN_LOGINMENU_19", "új hozzászólás");
define("LAN_LOGINMENU_20", "új fórum üzenet");
define("LAN_LOGINMENU_21", "új fórum üzenet");
define("LAN_LOGINMENU_22", "új tag");
define("LAN_LOGINMENU_23", "új tag");
define("LAN_LOGINMENU_24", "Kattints ide a listához");
define("LAN_LOGINMENU_25", "Utolsó látogatásod óta");
define("LAN_LOGINMENU_26", "nincs");
define("LAN_LOGINMENU_27", "és");

define("LAN_LOGINMENU_31", "Új hírek számának mutatása");
define("LAN_LOGINMENU_34", "Új hozzászólások számának mutatása");
define("LAN_LOGINMENU_36", "Új tagok számának mutatása");

define("LAN_LOGINMENU_39", "Admin elhagyása");
define("LAN_LOGINMENU_40", "Aktiváló Email Újraküldése");
define("LAN_LOGINMENU_41", "Login Menü Beállítások");

define("LAN_LOGINMENU_37", "Mutat");
define("LAN_LOGINMENU_38", "Login Menü - további linkek");

define("LAN_LOGINMENU_42", "Login Menü - legutóbbi core értékek");
define("LAN_LOGINMENU_43", "Pozíció");
define("LAN_LOGINMENU_44", "hiányzó link cím");
define("LAN_LOGINMENU_45", "link(ek) -");
define("LAN_LOGINMENU_45a", "");
define("LAN_LOGINMENU_45b", "plugin");
define("LAN_LOGINMENU_46", "legutóbbi elemek -");
define("LAN_LOGINMENU_47", "Login Menü - legutóbbi plugin értékek");
define("LAN_LOGINMENU_48", "Menü beállítása");
define("LAN_LOGINMENU_49", "Email: ");
define("LAN_LOGINMENU_50", "Felhasználói név vagy Email: ");
define("LAN_LOGINMENU_51", "Bejelentkezés");
