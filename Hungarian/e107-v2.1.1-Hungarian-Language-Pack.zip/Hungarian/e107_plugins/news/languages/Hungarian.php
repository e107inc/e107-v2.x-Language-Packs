<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("TD_MENU_L1", "Egyéb hírek");
define("TD_MENU_L2", "Egyéb hírek");
define("LAN_NEWSCAT_MENU_TITLE", "Hírkategóriák");
define("LAN_NEWSLATEST_MENU_TITLE", "Legfrissebb hírek");
