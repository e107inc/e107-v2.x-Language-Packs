<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("CHATBOX_L1", "Ezzel a névvel nem írhatsz bejegyzést, mivel a megadott név egy regisztrált felhasználóhoz tartozik. - Amennyiben a név hozzád tartozik, jelentkezz be.");
define("CHATBOX_L3", "Bejegyzés írásához be kell hogy jelentkezz. Amennyiben még nem regisztráltál az oldalra, <a href='".e_SIGNUP."'>ide</a> kattintva megteheted.");
define("CHATBOX_L4", "Bejegyzés írása");
define("CHATBOX_L5", "Reset");
define("CHATBOX_L6", "[letiltott: admin]");
define("CHATBOX_L7", "Feloldás");
define("CHATBOX_L8", "Info");
define("CHATBOX_L9", "Tiltás");
define("CHATBOX_L11", "Még nincs bejegyzés.");
define("CHATBOX_L12", "Összes üzenet");
define("CHATBOX_L13", "chatbox moderálása");
define("CHATBOX_L14", "Hangulatjelek");
define("CHATBOX_L15", "A bejegyzésed túl hosszú, vagy üresen lett elküldve");
define("CHATBOX_L17", "Duplikált bejegyzés");
define("CHATBOX_L18", "Chatbox bejegyzés moderálva");
define("CHATBOX_L19", "Csak egy bejegyzés lehetséges minden " . (FLOODPROTECT? FLOODTIMEOUT: 'n/a') . " másodpercben");
define("CHATBOX_L20", "Chatbox (összes bejegyzés)");
define("CHATBOX_L22", "ekkor");
define("CHATBOX_L24", "Nem rendelkezel megfelelő jogosultsággal az oldal megtekintéséhez.");
define("CHATBOX_L25", "[ a bejegyzés tiltva lett ]");
define("LAN_CHATBOX_100", "Ide írd az üzenetet");
