<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Hungarian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/04/09 16:43:34
|
|        $Author: Yesszus $
+---------------------------------------------------------------+
*/
define("CHBLAN_11", "Megjelenítendő elemek száma");
define("CHBLAN_12", "Megjelenítendő elemek száma a chatbox-ban");
define("CHBLAN_20", "Chatbox beállítása");
define("CHBLAN_22", "Bejegyzések törlése, melyek régebbiek egy adott dátumnál");
define("CHBLAN_23", "Bejegyzések törlése, melyek régebbiek mint:   ");
define("CHBLAN_24", "Egy nap");
define("CHBLAN_25", "Egy hét");
define("CHBLAN_26", "Egy hónap");
define("CHBLAN_27", "- Összes törlése -");
define("CHBLAN_29", "Bejegyzések megjelenítése egy görgethető sávban, melynek magassága [x]");
define("CHBLAN_31", "Hangulatjelek megjelenítése");
define("CHBLAN_32", "Moderátor csoportja");
define("CHBLAN_33", "Felhasználó bejegyzéseinek újraszámítása megtörtént");
define("CHBLAN_34", "Felhasználó bejegyzéseinek újraszámítása");
define("CHBLAN_35", "Újraszámítás");
define("CHBLAN_36", "Chatbox-megjelenítési beállítások");
define("CHBLAN_37", "Normál chatbox");
define("CHBLAN_38", "Bejegyzések dinamikus frissítése JavaScript segítségével (AJAX)");
define("CHBLAN_42", "Felhasználó bejegyzéseinek száma jelenjen meg a profil oldalon");


?>