<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PLUGIN_CHATBOX_MENU_NAME", "Chatbox");
define("LAN_PLUGIN_CHATBOX_MENU_DESCRIPTION", "Chatbox menü");
define("LAN_PLUGIN_CHATBOX_MENU_POSTS", "Chatbox bejegyzések");

define("LAN_AL_CHBLAN_01", "Chatbox-beállítások frissítve");
define("LAN_AL_CHBLAN_02", "Chatbox bejegyzések törölve");
define("LAN_AL_CHBLAN_03", "Chatbox bejegyzések újraszámítása sikerült");
define("LAN_AL_CHBLAN_04", "");
define("LAN_AL_CHBLAN_05", "");

define("NT_LAN_CB_1", "Chatbox események");
define("NT_LAN_CB_2", "Bejegyzés elküldve");
define("NT_LAN_CB_3", "Írta:");
define("NT_LAN_CB_5", "Üzenet");
define("NT_LAN_CB_6", "Chatbox bejegyzés elküldve");
