<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PLUGIN_LISTNEW_NAME", "Újdonság lista");
define("LAN_PLUGIN_LISTNEW_DESCRIPTION", "Ez a plugin lehetőséget ad, hogy az összes kategória újdonságait megjelenítse. Megtekintheted a listát az utolsó látogatásod óta a dátummal együtt vagy általánosan a legújabb hozzáadott listát. Ezenkívül egy menüt is megjeleníthetsz ugyanezekkel. Minden szekciót beállíthatsz az admin felületen.");
