<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LIST_MENU_1", "Legfrissebb");
define("LIST_MENU_2", "írta");
define("LIST_MENU_3", "ekkor");
define("LIST_MENU_4", "itt");
define("LIST_MENU_5", "nap");
define("LIST_MENU_6", "Válaszd ki hány napra visszamenőleg legyenek láthatók az újdonságok");
define("LIST_MENU_7", "");
define("LIST_MENU_8", "");
define("LIST_MENU_9", "");
define("LIST_MENU_10", "");
define("LIST_MENU_11", "");
define("LIST_MENU_12", "");
define("LIST_MENU_13", "");
define("LIST_MENU_14", "");
define("LIST_MENU_15", "");
define("LIST_MENU_16", "");
define("LIST_MENU_17", "");
define("LIST_MENU_18", "");
define("LIST_MENU_19", "");

define("LIST_NEWS_1", "hír");
define("LIST_NEWS_2", "nincs új hír");

define("LIST_COMMENT_1", "hozzászólás");
define("LIST_COMMENT_2", "nincs új hozzászólás");
define("LIST_COMMENT_3", "hír");
define("LIST_COMMENT_4", "GYIK");
define("LIST_COMMENT_5", "szavazás");
define("LIST_COMMENT_6", "dokumentum");
define("LIST_COMMENT_7", "hibajelentés");
define("LIST_COMMENT_8", "tartalom");
define("LIST_COMMENT_9", "");
define("LIST_COMMENT_10", "ötlet");

define("LIST_MEMBER_1", "tag");
define("LIST_MEMBER_2", "nincs új tag");

define("LIST_CONTENT_1", "tartalom");
define("LIST_CONTENT_2", "nincs új tartalom");
define("LIST_CONTENT_3", "nincs érvényes tartalom kategória");

define("LIST_CHATBOX_1", "chatbox");
define("LIST_CHATBOX_2", "nincs új chatbox üzenet");

define("LIST_CALENDAR_1", "naptár");
define("LIST_CALENDAR_2", "nincs új naptári esemény");

define("LIST_LINKS_1", "link");
define("LIST_LINKS_2", "nincs új link");

define("LIST_FORUM_1", "fórum");
define("LIST_FORUM_2", "nincs új fórum bejegyzés");
define("LIST_FORUM_3", "látták:");
define("LIST_FORUM_4", "válaszok:");
define("LIST_FORUM_5", "utolsó válasz:");
define("LIST_FORUM_6", "ekkor:");

define("LIST_LAN_1", "nincs változás: ");
