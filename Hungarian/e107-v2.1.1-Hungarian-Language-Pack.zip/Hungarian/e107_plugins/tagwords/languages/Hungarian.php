<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_TAG_INS_1", "Tagwords");
define("LAN_TAG_INS_2", "Egy teljes értékű Tagword (címke-kezelő) rendszer");
define("LAN_TAG_INS_3", "Tagwords beállítása");
define("LAN_TAG_INS_4", "Tagwords telepítve<br>A plugin beállításaihoz kattints a linkre a plugin résznél, az admin főoldalon.");

define("LAN_TAG_SEARCH_1", "Keresés:");
define("LAN_TAG_SEARCH_2", "Keresés");
define("LAN_TAG_SEARCH_3", "Nézet");

define("LAN_TAG_1", "TagWords");
define("LAN_TAG_2", "Címke");
define("LAN_TAG_3", "TagWords frissítve");
define("LAN_TAG_4", "rendezés ");
define("LAN_TAG_5", "megjelenítés ");
define("LAN_TAG_6", "");
define("LAN_TAG_7", "< Vissza a Tagwords főoldalára");
define("LAN_TAG_8", "eredmény található erre:");
define("LAN_TAG_9", "eredmény található erre:");
define("LAN_TAG_10", "betűrendben");
define("LAN_TAG_11", "méret szerint");
define("LAN_TAG_12", "címkelista");
define("LAN_TAG_13", "címkefelhő");
define("LAN_TAG_14", "kiválasztás : ");
define("LAN_TAG_15", "minden területen");
define("LAN_TAG_16", "TagCloud");
define("LAN_TAG_17", "TagList");
define("LAN_TAG_18", "nem található a címke ebben a szekcióban");
define("LAN_TAG_19", "válassz rendezési módot");
define("LAN_TAG_20", "válassz stílust");
define("LAN_TAG_21", "minden címke külön sorban");

define("LAN_TAG_OPT_1", "tagwords beállítások");
define("LAN_TAG_OPT_2", "minimális mennyiség szó szükséges a címkefelhőhöz/címkelistához");
define("LAN_TAG_OPT_3", "címkefelhő/címkelista csak nekik látható:");
define("LAN_TAG_OPT_4", "alapértelmezett címke rendezés");
define("LAN_TAG_OPT_5", "betűrendben");
define("LAN_TAG_OPT_6", "méret szerint");
define("LAN_TAG_OPT_7", "alapértelmezett címke stílus");
define("LAN_TAG_OPT_8", "címkefelhő");
define("LAN_TAG_OPT_9", "címkelista");
define("LAN_TAG_OPT_10", "igen");
define("LAN_TAG_OPT_11", "nem");
define("LAN_TAG_OPT_12", "beállítható címke rendezések");
define("LAN_TAG_OPT_13", "beállítható címke típusok");
define("LAN_TAG_OPT_14", "beállítható címke területek");
define("LAN_TAG_OPT_15", "szavak maximális száma a menüben");
define("LAN_TAG_OPT_16", "tagwords oldal");
define("LAN_TAG_OPT_17", "tagwords menü");
define("LAN_TAG_OPT_18", "menü címe");
define("LAN_TAG_OPT_19", "beállítható címke keresés");
define("LAN_TAG_OPT_20", "gyakoriság a szavak után");
define("LAN_TAG_OPT_21", "rövidkód");
define("LAN_TAG_OPT_22", "szó elválasztó");
define("LAN_TAG_OPT_23", "területek");
define("LAN_TAG_OPT_24", "aktív területek ellenőrzése");
define("LAN_TAG_OPT_25", "általános");
define("LAN_TAG_OPT_26", "megjelenítés");

define("LAN_TAG_MENU_1", "teljes tagwords felhő");
define("LAN_TAG_MENU_2", "Tagwords");

define("LAN_TAG_CORE_NEWS_1", "Hírek");
define("LAN_TAG_CORE_CPAGES_1", "Oldalak");

define("LAN_TAG_URL_NAME", "Tagwords");
define("LAN_TAG_URL_DEFAULT_LABEL", "Alapértelmezett");
define("LAN_TAG_URL_DEFAULT_DESCR", "Példa: http://yoursite.com/tagwords/some-tag");
