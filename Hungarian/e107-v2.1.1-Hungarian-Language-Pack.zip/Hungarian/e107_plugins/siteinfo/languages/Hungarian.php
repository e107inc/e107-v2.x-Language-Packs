<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("COMPLIANCE_L1", "W3C megfelelés");
define("SITEBUTTON_MENU_L1", "Ránk mutató link");
define("POWEREDBY_L1", "Powered by");

define("COUNTER_L1", "Admin látogatások naplózása kikapcsolva.");
define("COUNTER_L2", "Ezen a lapon ma ...");
define("COUNTER_L3", "összesen");
define("COUNTER_L4", "Ezen az oldalon már ...");
define("COUNTER_L5", "egyedi");
define("COUNTER_L6", "Oldal ...");
define("COUNTER_L7", "Számláló");
define("COUNTER_L8", "Admin üzenet: <b>Naplózás kikapcsolva.</b><br>Az aktiváláshoz telepítened kell a Statisztika plugint a <a href='".e_ADMIN."plugin.php'>plugin-kezelőben</a>, majd aktiválni azt a <a href='".e_PLUGIN."log/admin_config.php'>beállítások oldalon</a>.");
