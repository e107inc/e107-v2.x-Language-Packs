<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PLUGIN_FAQS_NAME", "GYIK");
define("LAN_PLUGIN_FAQS_DESCRIPTION", "Egyszerű GYIK plugin.");
define("LAN_PLUGIN_FAQS_FUNCTIONNAME", "GYIK kategóriák");
define("LAN_PLUGIN_FAQS_FRONT_NAME", "GYIK (gyakran ismételt kérdések)");
define("LAN_PLUGIN_FAQS_SEARCH", "GYIK Kereső");
