<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LANA_FAQ_QUESTION", "Kérdés");
define("LANA_FAQ_ANSWER", "Válasz");
define("LANA_FAQ_COMMENT", "Hozzászólás");
define("LANA_FAQ_UNAME", "Felhasználói név");
define("LANA_FAQ_ULOGINNAME", "Bejelentkezési név");
define("LANA_FAQ_TAGS", "Címkék");
define("LANA_FAQ_TAGS_HELP", "Vesszővel elválasztott címke lista");
define("LANA_FAQ_METAD", "Meta leírás");
define("LANA_FAQ_METAK", "Meta kulcsszavak");

define("LANA_FAQ_PREF_1", "Beküldés engedélyezése");
define("LANA_FAQ_PREF_2", "'Kérdés feltevése' korlátozása");
define("LANA_FAQ_PREF_3", "Klasszikus elrendezés használata");
