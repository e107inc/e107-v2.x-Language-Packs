<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_FAQS_TAGS", "Címkék");
define("LAN_FAQS_FILTER_ACTIVE", "Aktív");
define("LAN_FAQS_NONE_AVAILABLE", "Jelenleg nincs GYIK bejegyzés.");
define("LAN_FAQS_ASKQUESTION_AFTER", "Köszönjük. A kérdésed el lett mentve és remélhetőleg hamarosan meg is lesz válaszolva..");
