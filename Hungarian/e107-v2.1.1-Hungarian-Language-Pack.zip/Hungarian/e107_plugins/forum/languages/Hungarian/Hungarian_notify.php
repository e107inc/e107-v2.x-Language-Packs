<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_FORUM_NT_7", "Fórum - téma létrehozva új felhasználó által");
define("LAN_FORUM_NT_8", "Fórum - téma törölve lett");
define("LAN_FORUM_NT_9", "Fórum - téma darabolva lett");
define("LAN_FORUM_NT_10", "Fórum - bejegyzés törölve lett");
define("LAN_FORUM_NT_11", "Fórum - bejegyzés jelentve lett");

define("LAN_FORUM_NT_NEWTOPIC", "Új téma lett létrehozva");
define("LAN_FORUM_NT_NEWTOPIC_PROB", "Új téma lett létrehozva \"próbaidős\" felhasználó által");
define("LAN_FORUM_NT_TOPIC_DELETED", "Téma törölve lett");
define("LAN_FORUM_NT_TOPIC_SPLIT", "Téma darabolva lett");
define("LAN_FORUM_NT_POST_DELETED", "Bejegyzés törölve lett");
define("LAN_FORUM_NT_POST_REPORTED", "Bejegyzés jelentve lett");
