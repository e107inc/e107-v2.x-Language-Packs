<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_FORUM_MENU_001", "Írta:");
define("LAN_FORUM_MENU_002", "Még nincs bejegyzés");
define("LAN_FORUM_MENU_003", "Új fórum üzenetek menü beállítása sikerült");
define("LAN_FORUM_MENU_004", "Felirat");
define("LAN_FORUM_MENU_005", "Hány bejegyzés legyen megjelenítve?");
define("LAN_FORUM_MENU_006", "Hány karakter legyen megjelenítve?");
define("LAN_FORUM_MENU_007", "Utótag a hosszú bejegyzések levágása után?");
define("LAN_FORUM_MENU_008", "Téma megjelenítése a menüben?");
define("LAN_FORUM_MENU_009", "Menü-beállítások frissítése");
define("LAN_FORUM_MENU_0010", "Új fórum üzenetek menü beállításai");

define("LAN_FORUM_MENU_0012", "Maximum ennyi időre visszamenőleg jelenjenek meg bejegyzések");
define("LAN_FORUM_MENU_0013", "Az értéket napokban megadva csökkentheti a lekérdezéshez szükséges időt nagyobb terhelés esetén.");
