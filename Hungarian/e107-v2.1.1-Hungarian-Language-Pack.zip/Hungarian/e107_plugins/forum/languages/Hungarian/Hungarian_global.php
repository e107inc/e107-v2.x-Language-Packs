<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Hungarian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/04/09 15:49:02
|
|        $Author: Yesszus $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_FORUM_NAME", "Fórum");
define("LAN_PLUGIN_FORUM_DESC", "Ez a plugin egy teljes értékű fórum rendszert kínál.");
define("LAN_PLUGIN_FORUM_POSTS", "Fórum bejegyzések");
define("LAN_PLUGIN_FORUM_ALLFORUMS", "Összes fórum");
define("LAN_PLUGIN_FORUM_LATESTPOSTS", "Utolsó bejegyzés");
define("FORUM_LAN_URL_DEFAULT_LABEL", "Alapértelmezett fórum URL címek");
define("FORUM_LAN_URL_DEFAULT_DESCR", "\"GET\" típusú URL-ek. Példák:<br>http://yoursite.com/e107_plugins/Forum/forum.php (index fórum)<br>http://yoursite.com/e107_plugins/Forum/forum_viewtopic.php?id=2 (a hozzászóláslánc-nézetet)");
define("FORUM_LAN_URL_REWRITE_LABEL", "SEF fórum URL-ek (fejlesztés alatt)");
define("FORUM_LAN_URL_REWRITE_DESCR", "Példák:<br>FEJLESZTÉS ALATT");


?>