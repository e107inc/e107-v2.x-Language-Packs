<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Hungarian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/05/06 12:23:13
|
|        $Author: Yesszus $
+---------------------------------------------------------------+
*/

define("LAN_GALLERY_FRONT_01", "Jobb-klikk > Link Mentése Mint");


?>