<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Hungarian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/05/06 12:24:27
|
|        $Author: Yesszus $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_GALLERY_TITLE", "Galéria");
define("LAN_PLUGIN_GALLERY_DIZ", "Egyszerű képgaléria kezelő plugin");
define("LAN_PLUGIN_GALLERY_SEF_01", "Galéria SEF");
define("LAN_PLUGIN_GALLERY_SEF_02", "SEF URL-k engedélyezve.");
define("LAN_PLUGIN_GALLERY_SEF_03", "SEF URL-k letiltva.");
define("LAN_PLUGIN_GALLERY_SEF_04", "Alapértelmezett galéria");


?>