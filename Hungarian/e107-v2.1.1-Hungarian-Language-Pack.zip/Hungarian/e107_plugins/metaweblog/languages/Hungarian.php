<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("XMLRPC_ADMIN_001", "Főmenü");
define("XMLRPC_CONFIG_001", "MetaWeblog :: beállítás");
define("XMLRPC_PREFS_001", "eXMLRPC - beállítások");
define("XMLRPC_PREFS_002", "eXMLRPC");
define("XMLRPC_PREFS_003", "Hírek renderelési típusa (0,1,2,3)");
define("XMLRPC_PREFS_004", "Feltöltési könyvtár (e_FILE/)");
define("XMLRPC_PREFS_005", "Blog ID a klienshez");
define("XMLRPC_PREFS_006", "Blog név a klienshez");

define("XMLRPC_HELP_001", "Utasítások");
define("XMLRPC_HELP_010", "Általános");
define("XMLRPC_HELP_011", "Ez a plugin önmagában nem csinál semmit! Csupán néhány XMLRPC beállításra ad lehetőséget. Az XMLRPC kliensednek (pl.: a Windows Live Writer) ide kell mutatnia: <strong>'. SITEURL.' metaweblog.php</strong> , továbbá töltsd ki a kívánt értékeket. Figyelem! Ez a plugin kísérleti stádiumban van!");
define("XMLRPC_HELP_020", "Plugin neve");
define("XMLRPC_HELP_021", "Függetlenül attól, hogy a plugin nem rendelkezik kimenettel");
define("XMLRPC_HELP_030", "Hírek renderelési típusa");
define("XMLRPC_HELP_031", "Fontos! Alapértelmezett renderelési típus a hírekhez");
define("XMLRPC_HELP_040", "Feltöltési mappa a fájloknak");
define("XMLRPC_HELP_041", "Minden esetben az e107_files mappán belüli mappa!");
define("XMLRPC_HELP_050", "Blog ID a klienshez");
define("XMLRPC_HELP_051", "Blog Id XMLRPC ügyfél (bármilyen kívánt karakterlánc)");
define("XMLRPC_HELP_060", "Blog név a klienshez");
define("XMLRPC_HELP_061", "Blog név az XMLRPC klienshez (bármilyen karaktersorozat)");
