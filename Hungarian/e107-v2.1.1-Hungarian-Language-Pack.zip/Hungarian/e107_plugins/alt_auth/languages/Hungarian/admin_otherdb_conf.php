<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("OTHERDB_LAN_1", "Adatbázis típusa:");
define("OTHERDB_LAN_2", "Kiszolgáló:");
define("OTHERDB_LAN_3", "Felhasználónév:");
define("OTHERDB_LAN_4", "Jelszó:");
define("OTHERDB_LAN_5", "Adatbázis");
define("OTHERDB_LAN_6", "Tábla");
define("OTHERDB_LAN_7", "Felhasználói név - mező:");
define("OTHERDB_LAN_8", "Jelszó - mező:");
define("OTHERDB_LAN_9", "Jelszó metódus:");
define("OTHERDB_LAN_10", "Otherdb hitelesítés beállítása");
define("OTHERDB_LAN_12", "Jelszó (sózott) - mező:");
define("OTHERDB_LAN_13", "(Üresen hagyva nem lesz használatban)");
define("OTHERDB_LAN_14", "E-mail cím - mező:");
define("OTHERDB_LAN_15", "MySQL - általános adatbázis");
define("LAN_AUTHENTICATE_HELP", "Ezzel a hitelesítési módszerrel lehetőség van \"nem E107\" adatbázissal történő hitelesítésre. A jelszó egy, a támogatott tárolási formátumnak megfeleőnek kell lennie.");
