<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_AL_AUTH_01", "Alternatív hitelesítés beállításai megváltoztak");
define("LAN_AL_AUTH_02", "Alternatív hitelesítés bővített felhasználói csoportok megváltoztak");
define("LAN_AL_AUTH_03", "Alternatív hitelesítés módszer beállításai megváltoztak");
