<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_RADIUS_01", "Kiszolgáló címe");
define("LAN_RADIUS_02", "Titkos kulcs");
define("LAN_RADIUS_03", "Felhasználónév a kiszolgálóhoz");
define("LAN_RADIUS_04", "Jelszó a kiszolgálóhoz");
define("LAN_RADIUS_06", "RADIUS-hitelesítés beállítása");
define("LAN_RADIUS_11", "Figyelmeztetés: Úgy tűnik, hogy a RADIUS-modul jelenleg nem áll rendelkezésre; a jelenlegi hitelesítési módszer beállításai valószínűleg nem lesznek megfelelőek a RADIUS számára!");
define("LAN_AUTHENTICATE_HELP", "Ezzel a hitelesítési módszerrel lehetőség van egy külső RADIUS-kiszolgálóval hitelesíteni. Ehhez szükséges a PHP RADIUS bővítménye.<br>Vegye figyelembe, hogy a RADIUS-kiszolgáló lehet csak egy bizonyos IP-tartományból enged csatlakozni.");
