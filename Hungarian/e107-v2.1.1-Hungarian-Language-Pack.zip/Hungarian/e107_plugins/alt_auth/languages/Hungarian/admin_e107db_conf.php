<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("E107DB_LAN_1", "E107 formátumú adatbázis");
define("E107DB_LAN_9", "Jelszó metódus:");
define("E107DB_LAN_10", "E107 db hitelesítés beállítása");
define("E107DB_LAN_11", "Pipáld be azon mezőket, melyek értékeit szeretnéd átemelni a helyi adatbázisba:");

define("IMPORTDB_LAN_7", "MD5 (E107 sima)");
define("IMPORTDB_LAN_8", "E107 (salted) (v2+ opció)");

define("LAN_AUTHENTICATE_HELP", "Ez a hitelesítési módszer egy olyan másodlagos E107 adatbázissal lesz használva, amely eltérő formátumot használ a jelszavak tárolására. Az eredeti jelszó a helyi adatbázisból kerül kiolvasásra, és az eredeti rendszer tárolási formátumának használatával kerül hitelesítésre. Ha a hitelesítés sikerült, a jelszó konvertálva lesz az e107 formátumra, és el lesz mentve az adatbázisba.");
