<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LDAPLAN_1", "Kiszolgáló címe");
define("LDAPLAN_2", "Base DN vagy Domain<br>LDAP - esetén a Base DN<br>AD - eseténaz FQDN vagy pl: ad.mydomain.co.uk");
define("LDAPLAN_3", "LDAP-böngésző felhasználó<br>A felhasználó, aki keresni képes a könyvtárban.");
define("LDAPLAN_4", "LDAP-böngésző jelszó<br>LDAP-böngésző felhasználó jelszava.");
define("LDAPLAN_5", "LDAP-verzió");
define("LDAPLAN_6", "LDAP-hitelesítés beállítása");
define("LDAPLAN_7", "eDirectory keresési szűrő:");
define("LDAPLAN_8", "Ez lesz használva annak érdekében, hogy a felhasználói név a helyes struktúrában legyen,<br>pl: '(objectclass=inetOrgPerson)'");
define("LDAPLAN_9", "Jelenlegi keresési szűrő ez lesz:");
define("LDAPLAN_10", "Beállítások frissítése megtörtént");
define("LDAPLAN_11", "Figyelmeztetés: Úgy tűnik, hogy az LDAP-modul jelenleg nem áll rendelkezésre; a jelenlegi hitelesítési módszer beállítások lehet, hogy nem lesznek megfelelőek az LDAP számára!");
define("LDAPLAN_12", "Kiszolgáló típusa");
define("LDAPLAN_13", "Beállítások frissítése");
define("LDAPLAN_14", "OU az AD-hez (pl: ou=itdept)");

define("LAN_AUTHENTICATE_HELP", "Ez a metódus a legtöbb LDAP szerverhez használható, beleértve a Novell eDirectory-t és Microsoft Active Directory-t. Ehhez szükséges a PHP LDAP bővítménye. További információért keresd fel a Wikit.");
