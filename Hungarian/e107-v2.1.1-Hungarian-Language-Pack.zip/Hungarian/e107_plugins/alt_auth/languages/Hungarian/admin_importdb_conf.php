<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("IMPORTDB_LAN_9", "Jelszó metódus:");
define("IMPORTDB_LAN_10", "Importált adatbázis jelszó típusának beállítása");
define("IMPORTDB_LAN_11", "Ez a beállítás akkor használatos, ha más felhasználó-alapú rendszereket importálsz E107-be. Ez lehetővé teszi, hogy elfogadja a nem szabványos formátumban kódolt jelszavakat. Minden felhasználó jelszava E107 formátumra lesz konvertált, amikor bejelentkeznek.");

define("LAN_AUTHENTICATE_HELP", "Ez a hitelesítési módszer <i>csak</i> akkor használatos, ha egy felhasználói adatbázist importálsz e107-be, és a jelszó formátuma inkompatibilis. Az eredeti jelszó a helyi adatbázisból kerül kiolvasásra, és az eredeti rendszer tárolási formátumának használatával kerül hitelesítésre. Ha a hitelesítés sikerült, a jelszó konvertálva lesz az e107 formátumra, és el lesz mentve az adatbázisba. Tehát, ha idővel kikapcsolnád az alternatív hitelesítést, a felhasználók akkor is be tudnak majd lépni, az eredeti jelszavuk használatával.");
