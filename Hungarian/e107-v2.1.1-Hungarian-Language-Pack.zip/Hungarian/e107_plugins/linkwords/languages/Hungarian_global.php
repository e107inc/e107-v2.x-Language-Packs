<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PLUGIN_LINKWORDS_NAME", "Linkszó");
define("LAN_PLUGIN_LINKWORDS_DESCRIPTION", "A plugin linket rendel a megadott szavakhoz.");
