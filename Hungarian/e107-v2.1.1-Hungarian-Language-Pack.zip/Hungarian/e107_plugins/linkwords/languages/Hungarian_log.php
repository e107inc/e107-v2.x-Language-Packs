<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_AL_LINKWD_00", "Linkszóhoz kapcsolódó üzenet");
define("LAN_AL_LINKWD_01", "Linkszó hozzáadva");
define("LAN_AL_LINKWD_02", "Linkszó szerkesztve");
define("LAN_AL_LINKWD_03", "Linkszó törölve");
define("LAN_AL_LINKWD_04", "Linkszó beállításai frissítve");
define("LAN_AL_LINKWD_05", "Linkszó verzió frissítés");
