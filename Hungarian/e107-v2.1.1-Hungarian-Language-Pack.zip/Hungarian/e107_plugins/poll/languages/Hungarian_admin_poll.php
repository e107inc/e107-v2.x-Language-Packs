<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("POLL_ADLAN03", "Szavazás beállítása");
define("POLL_ADLAN04", "A szavazás plugin telepítve. Szavazás létrehozásához kattints a Szavazás ikonra az admin területen, és aktiváld a menüt a Menü-kezelőben.");
define("POLL_ADLAN05", "Fő szavazás: ");
define("POLL_ADLAN06", "Fórum téma: ");
define("POLL_ADLAN07", "Típus ");

define("POLLAN_MENU_CAPTION", "Szavazás");

define("POLLAN_7", "Még nincs szavazás.");
define("LAN_AL_POLL_01", "Szavazás törölve");
define("LAN_AL_POLL_02", "Szavazás frissítve");
define("LAN_AL_POLL_03", "Szavazás létrehozva");
define("LAN_AL_POLL_04", "");
define("LAN_AL_POLL_05", "");
