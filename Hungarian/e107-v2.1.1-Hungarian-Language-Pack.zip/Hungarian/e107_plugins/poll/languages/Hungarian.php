<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("POLLAN_MENU_CAPTION", "Szavazás");

define("POLLAN_1", "Jelenlegi szavazások");
define("POLLAN_2", "Szavazások készítése / módosítása");
define("POLLAN_3", "Szavazás kérdése");
define("POLLAN_4", "Opciók");
define("POLLAN_8", "Új opció hozzáadása");
define("POLLAN_9", "Több válasz engedélyezése?");
define("POLLAN_10", "igen");
define("POLLAN_11", "nem");
define("POLLAN_12", "Eredmények mutatása");
define("POLLAN_13", "szavazás után");
define("POLLAN_14", "az eredmények linkre kattintva - a hozzászólásoknak bekapcsolva kell lennie, hogy használni tudd ezt az opciót");
define("POLLAN_15", "Szavazat engedélyezése");
define("POLLAN_16", "Szavazat tárolásának módja");
define("POLLAN_17", "cookie");
define("POLLAN_18", "IP cím");
define("POLLAN_19", "UserID (csak tagok szavazhatnak)");
define("POLLAN_20", "Hozzászólások engedélyezése?");
define("POLLAN_21", "Ismételt előnézet");
define("POLLAN_22", "Szavazás frissítése");
define("POLLAN_23", "Szavazás készítése");
define("POLLAN_24", "Előnézet");
define("POLLAN_25", "Törlés");
define("POLLAN_26", "szavazat");
define("POLLAN_28", "Korábbi szavazások");
define("POLLAN_29", "kiírta");
define("POLLAN_30", "Mehet");
define("POLLAN_31", "szavazat");
define("POLLAN_32", "Eredmények megtekintése");
define("POLLAN_33", "Nincsenek korábbi szavazások.");
define("POLLAN_35", "Kiírta");
define("POLLAN_36", "Aktív");
define("POLLAN_37", "aktív:");
define("POLLAN_38", "-");
define("POLLAN_39", "Köszönjük a szavazatot!");
define("POLLAN_40", "Eredmények megtekintése");
define("POLLAN_41", "A szavazás korlátozva csak tagoknak");
define("POLLAN_42", "A szavazás korlátozva csak adminisztrátoroknak");
define("POLLAN_43", "Nincs jogosultságod a szavazásra");
define("POLLAN_44", "Szavazás törlése?");
define("POLLAN_45", "Szavazás sikeresen frissítve");

define("LAN_FORUM_3029", "Ha nem szeretnél szavazást indítani a témában, egyszerűen hagyd üresen.");
define("LAN_FORUM_3030", "Szavazás kérdése");
define("LAN_FORUM_3031", "Szavazás válasza");
define("LAN_FORUM_3032", "További válasz hozzáadása");
define("LAN_FORUM_3033", "Több választási lehetőségek engedélyezése?");
define("LAN_FORUM_3034", "Szavazás tárolási módszer");
define("LAN_FORUM_3035", "Cookie-k");
define("LAN_FORUM_3036", "IP-cím");
define("LAN_FORUM_3037", "Felhasználó azonosítója (csak tagok szavazhatnak)");
