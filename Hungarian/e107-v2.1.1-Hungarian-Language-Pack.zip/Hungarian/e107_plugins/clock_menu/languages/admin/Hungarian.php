<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("CLOCK_AD_L2", "Felirat");
define("CLOCK_AD_L4", "Óra menü beállítása");
define("CLOCK_AD_L5", "de/du");
define("CLOCK_AD_L6", "Ha be van pipálva, az idő 12 órás formátumban lesz megjelenítve (0-12 de/du formátum). Ha nincs, úgy 24 órás formátumban (0-24-formátum)");
define("CLOCK_AD_L7", "Dátum előtag");
define("CLOCK_AD_L8", "Ha az adott nyelvhez szükséges egy rövid előtag a dátumhoz (pl: 'le' a franciánál, vagy 'den' a németnél). Ha üresen hagyod, nem fog megjelenni.");
define("CLOCK_AD_L9", "Utótag 1");
define("CLOCK_AD_L10", "Utótag 2");
define("CLOCK_AD_L11", "Utótag 3");
define("CLOCK_AD_L12", "Utótag 4 és több");
define("CLOCK_AD_L13", "Ha az adott nyelvhez szükséges egy rövid utótagra a dátumhoz (pl: 'st' az 1 után, 'nd' a 2 után, 'rd' a 3 után és 'th' a 4 után - angol nyelvű felhasználóknak). Ha üresen hagyod, nem fog megjelenni.");
