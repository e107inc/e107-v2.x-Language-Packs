<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("CLOCK_MENU_L1", "Óra menü beállítása sikerült");
define("CLOCK_MENU_L2", "Felirat");
define("CLOCK_MENU_L3", "Menü-beállítások frissítése");
define("CLOCK_MENU_L4", "Óra menü beállítása");
define("CLOCK_MENU_L5", "Hétfő,");
define("CLOCK_MENU_L6", "Kedd,");
define("CLOCK_MENU_L7", "Szerda,");
define("CLOCK_MENU_L8", "Csütörtök,");
define("CLOCK_MENU_L9", "Péntek,");
define("CLOCK_MENU_L10", "Szombat,");
define("CLOCK_MENU_L11", "Vasárnap,");
define("CLOCK_MENU_L12", "Január");
define("CLOCK_MENU_L13", "Február");
define("CLOCK_MENU_L14", "Március");
define("CLOCK_MENU_L15", "Április");
define("CLOCK_MENU_L16", "Május");
define("CLOCK_MENU_L17", "Június");
define("CLOCK_MENU_L18", "Július");
define("CLOCK_MENU_L19", "Augusztus");
define("CLOCK_MENU_L20", "Szeptember");
define("CLOCK_MENU_L21", "Október");
define("CLOCK_MENU_L22", "November");
define("CLOCK_MENU_L23", "December");
