<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("CM_L1", "Még nem érkezett hozzászólás.");
define("CM_L2", "");
define("CM_L3", "Felirat");
define("CM_L4", "Megjelenítendő Hozzászólások száma");
define("CM_L5", "Megjelenítendő karakterek száma");
define("CM_L6", "Utótag a hosszú hozzászólások után");
define("CM_L7", "Hír címének használata a menüben");
define("CM_L8", "Hozzászólások menü beállítása");
define("CM_L11", "ekkor");
define("CM_L12", "Válasz:");
define("CM_L13", "Írta:");
