<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_AL_DOWNL_01", "Letöltések - letöltési opciók megváltoztak");
define("LAN_AL_DOWNL_02", "Letöltések - feltöltési opciók megváltoztak");
define("LAN_AL_DOWNL_03", "Letöltések - korlátozás hozzáadva");
define("LAN_AL_DOWNL_04", "Letöltések - log 04");
define("LAN_AL_DOWNL_05", "Letöltések - log 05");
define("LAN_AL_DOWNL_06", "Letöltések - log 06");
define("LAN_AL_DOWNL_07", "Letöltések - log 07");
define("LAN_AL_DOWNL_08", "Letöltések - log 08");
define("LAN_AL_DOWNL_09", "Letöltések - log 09");
define("LAN_AL_DOWNL_10", "Letöltések - korlátozás frissítve");
define("LAN_AL_DOWNL_11", "Letöltések - korlátozás törölve");
