<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PLUGIN_DOWNLOAD_NAME", "Letöltések");
define("LAN_PLUGIN_DOWNLOAD_DIZ", "Ez a plugin egy teljes értékű letöltés-kezelő rendszer.");
