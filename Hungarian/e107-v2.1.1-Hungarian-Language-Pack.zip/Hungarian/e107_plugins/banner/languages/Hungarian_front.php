<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("PAGE_NAME", "Banner");
define("BANNERLAN_16", "Ügyfélnév:");
define("BANNERLAN_17", "Jelszó:");
define("BANNERLAN_19", "A folytatáshoz adja meg ügyfélnevét és jelszavát");
define("BANNERLAN_20", "Sajnáljuk, de a megadott adatokkal nem található ügyfél az adatbázisban. Kérjük, lépjen kapcsolatba az adminisztrátorral.");
define("BANNERLAN_21", "Banner statisztika");
define("BANNERLAN_22", "Ügyfél");
define("BANNERLAN_23", "Banner ID");
define("BANNERLAN_24", "Átkattintás");
define("BANNERLAN_25", "Kattintás %");
define("BANNERLAN_26", "Megjelenések");
define("BANNERLAN_27", "Megjelenések maximális száma");
define("BANNERLAN_28", "Hátralevő megjelenések száma");
define("BANNERLAN_29", "Nincsennek bannerek");
define("BANNERLAN_30", "Korlátlan");
define("BANNERLAN_31", "Nem elérhető");
define("BANNERLAN_34", "Befejezés:");
define("BANNERLAN_35", "Átkattintások IP-címei");
define("BANNERLAN_36", "Aktív:");
define("BANNERLAN_37", "Kezdés:");
