<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PLUGIN_LOG_NAME", "Statisztika");
define("LAN_PLUGIN_LOG_DESCRIPTION", "A plugin minden látogatást naplózni fog, és részletes statisztikákat ad az összegyűjtött információk alapján.");
define("LAN_PLUGIN_LOG_CONFIGURE", "Statisztika beállítása");
define("LAN_PLUGIN_LOG_LINK", "Statisztika");
