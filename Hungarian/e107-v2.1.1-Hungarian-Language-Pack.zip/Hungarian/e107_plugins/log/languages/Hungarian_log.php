<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_AL_STAT_01", "Statisztika - nullázás");
define("LAN_AL_STAT_02", "Statisztika - beállítások megváltoztak");
define("LAN_AL_STAT_03", "Statisztika - oldalak törölve");
define("LAN_AL_STAT_04", "Statisztika - naplózás törölve");
