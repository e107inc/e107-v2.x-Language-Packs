<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PLUGIN_IMPORT_NAME", "E107 importálás");
define("LAN_PLUGIN_IMPORT_DESCRIPTION", "Adatok importálása Wordpress-ből, Joomla-ból, Drupal-ból, Blogpost-ból, vagy RSS és egyéb formátumokból.");
