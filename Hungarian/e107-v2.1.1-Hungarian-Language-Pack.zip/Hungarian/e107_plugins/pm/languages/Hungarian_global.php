<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Hungarian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/04/09 15:47:50
|
|        $Author: Yesszus $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_PM_NAME", "Privát Üzenet");
define("LAN_PLUGIN_PM_DESCRIPTION", "Ez a plugin egy minden tulajdonsággal felruházott Privát Üzenetküldő Rendszer.");
define("LAN_PLUGIN_PM_URL_DEFAULT_LABEL", "Alapértelmezett");
define("LAN_PLUGIN_PM_URL_DEFAULT_DESCR", "Alapértelmezett");
define("LAN_PLUGIN_PM_INBOX", "Bejövő");
define("LAN_PLUGIN_PM_OUTBOX", "Kimenő");


?>