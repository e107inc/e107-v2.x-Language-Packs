<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Hungarian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/04/09 15:47:50
|
|        $Author: Yesszus $
+---------------------------------------------------------------+
*/

define("LAN_EC_PM_01", "");
define("LAN_EC_PM_02", "");
define("LAN_EC_PM_03", "");
define("LAN_EC_PM_04", "PM-kezelő");
define("LAN_EC_PM_05", "Tömeges PM küldés folyamatban");
define("LAN_EC_PM_06", "Tömeges PM küldés indítása, küldés --NUM-- címzettnek.");
define("LAN_EC_PM_07", "");
