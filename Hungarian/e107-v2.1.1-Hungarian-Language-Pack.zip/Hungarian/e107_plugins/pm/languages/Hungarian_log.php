<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_AL_PM_ADM_01", "PM: Alapértelmezett beállítások használata");
define("LAN_AL_PM_ADM_02", "PM: Beállítások frissítve");
define("LAN_AL_PM_ADM_03", "PM: DB karbantartás befejeződött");
define("LAN_AL_PM_ADM_04", "PM: DB karbantartási elkezdődött");
define("LAN_AL_PM_ADM_05", "PM: Limit hozzáadva");
define("LAN_AL_PM_ADM_06", "PM: Limit frissítve");
define("LAN_AL_PM_ADM_07", "PM: Limit törölve");
define("LAN_AL_PM_ADM_08", "PM: Hiba lépett fel a limit hozzáadásakor");
define("LAN_AL_PM_ADM_09", "PM: Hiba lépett fel a limit frissítésekor");
define("LAN_AL_PM_ADM_10", "PM: Hiba lépett fel a limit törlésekor");
