<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("ADLAN_PM_1", "Az aktiváláshoz lépj a menük felületre és válaszd ki a private_msg majd helyezd valamelyik menüterületre. <br /><br />Ha szükséges az előző verzió üzeneteinek konvertálása, akkor lépj a plugin Fő beállítások oldalára és válaszd a 'Konvertálás' linket.");
define("ADLAN_PM_3", "PM beállítások nem találhatóak, alapértelmezett beállítások kiválasztva");
define("ADLAN_PM_4", "Beállítások frissítve");
define("ADLAN_PM_5", "Limit, a kiválasztott felhasználó csoport számára már létezik");
define("ADLAN_PM_6", "Limit sikeresen hozzáadva");
define("ADLAN_PM_7", "Limit nem lett hozzáadva - ismeretlen hiba");
define("ADLAN_PM_8", "Limit állapot frissítve");
define("ADLAN_PM_9", " - Limit sikeresen frissítve");
define("ADLAN_PM_10", " - Limit nem lett törölve - ismeretlen hiba");
define("ADLAN_PM_11", " - Limit sikeresen frissítve");
define("ADLAN_PM_12", "PM Beállítások");
define("ADLAN_PM_13", "PM Konverzió");
define("ADLAN_PM_14", "PM Limitek");
define("ADLAN_PM_15", "PM Limit hozzáadása");
define("ADLAN_PM_16", "Plugin Cím");
define("ADLAN_PM_17", "Új PM animáció mutatása");
define("ADLAN_PM_18", "Felhasználói legördülődoboz mutatása");
define("ADLAN_PM_19", "Olvasott üzenet időkifutása");
define("ADLAN_PM_20", "Nem olvasott üzenetek időkifutása");
define("ADLAN_PM_21", "Popup értesítés új PM érkezésekor");
define("ADLAN_PM_22", "Popup késleltetés ideje");
define("ADLAN_PM_23", "PM küldés korlátozása a következők részére");
define("ADLAN_PM_24", "PM üzenet száma / oldal");
define("ADLAN_PM_25", "PM email értesítés engedélyezése");
define("ADLAN_PM_26", "Visszaigazoló értesítő email engedélyezése a felhasználóknak");
define("ADLAN_PM_27", "Melléklet küldés engedélyezése");
define("ADLAN_PM_28", "Maximális melléklet méret");
define("ADLAN_PM_29", "Összes tagnak küldés engedélyezése");
define("ADLAN_PM_30", "Összetett visszaigazoló értesítés küldésének engedélyezése");
define("ADLAN_PM_31", "Felhasználó csoportnak küldés engedélyezése");
define("ADLAN_PM_33", "Inaktív (nincs limit)");
define("ADLAN_PM_34", "PM számolás");
define("ADLAN_PM_35", "PM levelesláda mérete");
define("ADLAN_PM_36", "Felhasználó csoport");
define("ADLAN_PM_37", "Mennyiségi limit");
define("ADLAN_PM_38", "Méret limit (KB-ban)");
define("ADLAN_PM_39", "Beérkező levelek");
define("ADLAN_PM_40", "Elküldött levelek");
define("ADLAN_PM_41", "Jelenleg nincs limit beállítva.");
define("ADLAN_PM_44", "másodperc");
define("ADLAN_PM_45", "PM limit beállítva: ");

define("ADLAN_PM_54", "Fő beállítások");
define("ADLAN_PM_55", "korlátozás");

define("ADLAN_PM_59", "Karbantartás");
define("ADLAN_PM_60", "PM karbantartása");
define("ADLAN_PM_62", "Ezen funkció használatával, a törölt felhasználókhoz kapcsolódó bejegyzéseket lehet eltávolítani az adatbázis táblákból.");
define("ADLAN_PM_63", "Üzenetek elküldve");
define("ADLAN_PM_64", "Üzenetek fogadva");
define("ADLAN_PM_65", "Blokkolt felhasználók");
define("ADLAN_PM_66", "Nincs meghatározott karbantartási feladat");
define("ADLAN_PM_67", "PM DB karbantartás elkezdődött");
define("ADLAN_PM_68", "--COUNT-- blokkolás lett eltávolítva a törölt felhasználóknál");
define("ADLAN_PM_69", "--COUNT-- blokkolás lett eltávolítva a törölt felhasználóktól");
define("ADLAN_PM_70", "Adatbázis hiba: --NUM--: --TEXT-- blokkolt felhasználók eltávolítása közben");
define("ADLAN_PM_71", "Időtúllépési üzenetek");
define("ADLAN_PM_72", "Nincs PM időtúllépés beállítva");
define("ADLAN_PM_73", "--COUNT-- időtúllépéses PM lett törölve");
define("ADLAN_PM_74", "--COUNT-- üzenet lett törölve, melyeket törölt felhasználók küldtek");
define("ADLAN_PM_75", "--COUNT-- üzenet lett törölve, melyeket törölt felhasználóknak küldtek");
define("ADLAN_PM_77", "(Ürítsd ki a mezőket és frissítsd a limitek törlését)");
define("ADLAN_PM_78", "Mellékletek ellenőrzése");
define("ADLAN_PM_79", "--ORPHANS-- elárvult melléklet lett törölve. --MISSING-- hiányzó melléklet lett feljegyezve");
define("ADLAN_PM_80", "Előnyben részesített formátumok frissítve lettek");
define("ADLAN_PM_81", "Egyidejűleg küldhető PM-ek maximális száma");
define("ADLAN_PM_82", "Ha ennél több lesz elküldve, a rendszer az üzeneteket sorba fogja állítani, és ütemeve, az időzített futtatás segítségével küldi el őket.");
