<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("NLLAN_MENU_CAPTION", "Hírlevél");

define("NLLAN_48", "Hírlevélről való leiratkozás - a hírlevél lemondásához katt a lenti gombra.");
define("NLLAN_49", "Valóban szeretnél leiratkozni a hírlevélről?");
define("NLLAN_50", "Katt a gombra a feliratkozáshoz (feliratkozó címed a következő)");
define("NLLAN_51", "Leiratkozás");
define("NLLAN_52", "Feliratkozás");
define("NLLAN_53", "Valóban szeretnél feliratkozni a hírlevélre?");

define("NLLAN_67", "Archívum – áttekintés");
define("NLLAN_68", "Érvénytelen paraméter lett meghatározva");
define("NLLAN_69", "Nem elérhető elküldött hírlevél.");
define("NLLAN_70", "A kiválasztott hírlevél nem létezik");
define("NLLAN_71", "Vissza");
define("NLLAN_72", "Archivum megtekintése");
