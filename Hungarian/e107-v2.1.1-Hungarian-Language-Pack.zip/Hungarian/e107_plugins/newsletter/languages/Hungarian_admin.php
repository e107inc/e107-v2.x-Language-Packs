<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("NLLAN_04", "A Hírlevél plugin sikeresen telepítve. A beállításhoz lépj az admin főoldalra és katt a 'Hírlevél' linkre a plugin-ok felületen.");
define("NLLAN_05", "Még nincs hírlevél meghatározva");

define("NLLAN_07", "Feliratkozók");
define("NLLAN_10", "Meglévő Hírlevelek");

define("NLLAN_11", "Jelenleg nincs hírlevél");
define("NLLAN_12", "Kiadvány");
define("NLLAN_13", "[ Szülő ID ] Téma/Cím");
define("NLLAN_14", "Mail küldése?");
define("NLLAN_17", "Nincs kiküldve - katt a küldéshez");
define("NLLAN_18", "Biztosan elküldöd a hírlevelet a feliratkozóknak?");
define("NLLAN_19", "Biztosan törlöd a hírlevelet?");
define("NLLAN_20", "Meglévő Kiadványok");
define("NLLAN_23", "Fejléc");
define("NLLAN_24", "Lábléc");
define("NLLAN_30", "Hírlevél");
define("NLLAN_31", "Tárgy / Cím");
define("NLLAN_32", "Kiadvány száma");
define("NLLAN_33", "Szöveg");
define("NLLAN_36", "Hírlevél kiadvány frissítése");
define("NLLAN_37", "Hírlevél kiadvány létrehozása");
define("NLLAN_39", "Hírlevél kiadvány elmentve az adatbázisban - kiküldéshez, katt a 'Kiadvány kiadása' gombra a beállítások menüben.");
define("NLLAN_40", "Levélküldés ütemezve lett - --COUNT-- feliratkozónak lesz elküldve.");
define("NLLAN_41", "Nem találhatóak feliratkozók - email küldés leállítva");

define("NLLAN_44", "Hírlevél kezdőoldal");
define("NLLAN_45", "Hírlevél létrehozása");
define("NLLAN_46", "Levélküldés létrehozása");
define("NLLAN_47", "Hírlevél beállítások");
define("NLLAN_48", "Hírlevélre feliratkozottak");
define("NLLAN_49", "Hírlevél: ");

define("NLLAN_54", "Küldés");

define("NLLAN_56", "Hírlevél ID nem érvényes");
define("NLLAN_62", "Felhasználó kitiltva! (vagy nem teljesen regisztrált)");
define("NLLAN_63", "Összes felíratkozó");
define("NLLAN_64", "Vissza a hírlevél fooldalra");
define("NLLAN_65", "Felíratkozók átnézhetik a hírlevél ID-t");
define("NLLAN_66", "A hírlevélre feliratkozottak listája meg lett tisztítva.");
