<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PLUGIN_NEWSLETTER_NAME", "Hírlevél");
define("LAN_PLUGIN_NEWSLETTER_DESCRIPTION", "Egy könnyű és gyors lehetőséget biztosít a beállításhoz és a hírlevél elküldéséhez.");
