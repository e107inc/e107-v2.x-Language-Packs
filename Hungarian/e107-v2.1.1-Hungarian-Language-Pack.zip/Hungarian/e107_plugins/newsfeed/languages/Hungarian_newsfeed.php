<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("NFLAN_29", "Elérhető hírforrások");
define("NFLAN_31", "Vissza a hírforrás lisához");
define("NFLAN_33", "Közzététel dátuma:");
define("NFLAN_34", "nem ismert");
define("NFLAN_38", "Címsorok");
define("NFLAN_39", "Részletek");
define("NFLAN_48", "Nem lehet elmenteni ezeket az adatokat az adabázisba.");
