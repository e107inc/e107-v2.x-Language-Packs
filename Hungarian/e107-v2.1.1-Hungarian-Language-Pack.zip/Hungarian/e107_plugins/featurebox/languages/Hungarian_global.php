<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PLUGIN_FEATUREBOX_NAME", "Feature Box");
define("LAN_PLUGIN_FEATUREBOX_DESCRIPTION", "Hírek és egyéb elemek megjelenítése az oldal tetején egy animált területen.");
define("LAN_PLUGIN_FEATUREBOX_BATCH", "Elem hozzáadása");

define("FBLAN_INSTALL_01", "Alapértelmezett kategóriák hozzáadása.");
define("FBLAN_INSTALL_02", "Alapértelmezett értékek hozzáadása.");
define("FBLAN_INSTALL_03", "Nincs hozzárendelve");
define("FBLAN_INSTALL_04", "Carousel");
define("FBLAN_INSTALL_05", "Fülek");
