<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("FBLAN_08", "Üzenet szövege");
define("FBLAN_12", "Mód");
define("FBLAN_13", "Üzenetek véletlenszerű forgatása");
define("FBLAN_14", "Mutasd csak ezt az üzenetet");
define("FBLAN_22", "Renderelés típusa");
define("FBLAN_23", "Dobozban");
define("FBLAN_24", "Egyszerű");
