<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("PAGE_NAME", "Hír beküldése");
define("LAN_7", "Felhasználónév: ");
define("LAN_112", "Email cím: ");
define("LAN_133", "Köszönjük!");
define("LAN_134", "A beküldött hírt rögzítettük. Amint tudjuk ellenőrizzük.");
define("LAN_135", "Hír: ");
define("LAN_136", "Hír beküldése");
define("NWSLAN_6", "Kategória");
define("NWSLAN_10", "Nincs hírkategória!");

define("SUBNEWSLAN_1", "Meg kell adnod egy címet.\\n");
define("SUBNEWSLAN_2", "Meg kell adnod némi szöveget.\\n");
define("SUBNEWSLAN_3", "Csatolt kép engedélyezett formátumai: jpg, gif és png");
define("SUBNEWSLAN_4", "Túl nagy fájl");
define("SUBNEWSLAN_5", "Képfájl");
define("SUBNEWSLAN_6", "(jpg, gif vagy png)");
define("SUBNEWSLAN_7", "Meg kell adnod a nevedet és email címedet");
define("SUBNEWSLAN_8", "Kép feltöltési hiba");
