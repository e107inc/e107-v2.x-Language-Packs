<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_HEADER_01", "Admin Navigáció");
define("LAN_HEADER_02", "A szervered nem engedi a HTTP alapú fájl-feltöltést, tehát a  felhasználók nem fognak tudni avatart/fájlokat feltölteni. Ezen állapot megszüntetéséhez engedélyezd a file_uploads opciót a php.ini -ben és indítsd újra a szervert. Ha nincs jogosultságod a php.ini eléréséhez, lépj kapcsolatba a szerver adminisztrátorával.");
define("LAN_HEADER_03", "A szerver basedir korlátozással fut. Emiatt nem tudsz elérni semmilyen fájlt a saját könyvtárodon kívül. Ez bezavarhat néhány olyan szkriptnek, mint a fájlkezelő.");
define("LAN_HEADER_04", "Admin terület");
define("LAN_HEADER_05", "az adminterület nyelve");
define("LAN_HEADER_06", "Bővítmény részletezése");
