<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("FLALAN_2", "Nincs sikertelen belépési kísérlet rögzítve");
define("FLALAN_3", "Kísérlet törölve");
define("FLALAN_4", "A felhasználó a belépési kisérlethez nem megfelelő felhasználónevet/jelszót használt");
define("FLALAN_5", "IP(-k) kitiltva");
define("FLALAN_7", "Adat");
define("FLALAN_8", "IP cím/kiszolgáló");
define("FLALAN_10", "Törlése / kitíltás kiválasztása");
define("FLALAN_15", "A következő IP cím(-ek) automatikusan kitíltásra kerülnek - felhasználó 10-nél többször kisérelte meg a belépést");
define("FLALAN_16", "Automatikus kitiltás lista törlése");
define("FLALAN_17", "Automatikus kitiltás lista törölve");
define('FLALAN_18', "Nem lehet kitiltani a következő IP címet --IP-- - a fehérlistából");
