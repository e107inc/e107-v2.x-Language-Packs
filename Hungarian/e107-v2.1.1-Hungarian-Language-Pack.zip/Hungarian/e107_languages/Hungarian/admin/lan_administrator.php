<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("ADMSLAN_6", " főadminisztrátort nem lehet törölni!");

define("ADMSLAN_13", "Adminisztrátorok");

define("ADMSLAN_16", "Admin Név");
define("ADMSLAN_18", "Jogosultságok");
define("ADMSLAN_21", "Admin jogosultságok módosítása");
define("ADMSLAN_25", "Fájlok feltöltése /kezelése");
define("ADMSLAN_27", "Link kategóriák felügyelete");
define("ADMSLAN_41", "Saját menük/oldalak létrehozása");
define("ADMSLAN_42", "Visszajelzés küldése");

define("ADMSLAN_52", "Adminisztrátor frissítése");

define("ADMSLAN_56", "Adminisztrátor");

define("ADMSLAN_58", "Főadminisztrátor");
define("ADMSLAN_59", "Admin állapot törlése");

define("ADMSLAN_61", "Adminisztrátor törölve");

define("ADMSLAN_62", "Bővítmény kezelő");

define("ADMSLAN_71", "Katt ide a jogosultságok megtekintéséhez");

define("ADMSLAN_72", "Adminisztrátor ID: --ID-- név: --NAME-- új jogosultság: ");
define("ADMSLAN_73", "Adminisztrátor ID: --ID-- név: --NAME--");

define("ADMSLAN_74", "Általános");
