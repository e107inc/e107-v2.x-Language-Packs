<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("DBVLAN_1", "SQL adatfile beolvasása sikertelen<br /><br />Ellenőrizd, hogy a [b]core_sql.php[/b] fájl megtalálható az [b]/admin/sql[/b] könyvtárban.");

define("DBVLAN_4", "Tábla");
define("DBVLAN_5", "Mező");
define("DBVLAN_6", "Állapot");
define("DBVLAN_7", "Megjegyzés");
define("DBVLAN_8", "Eltérés");
define("DBVLAN_9", "Jelenleg");
define("DBVLAN_10", "kéne legyen");
define("DBVLAN_11", "Hiányzó mező!");
define("DBVLAN_12", "Extra mező!");
define("DBVLAN_13", "Hiányzó tábla!");
define("DBVLAN_14", "Válaszd ki az ellenőrizendő táblá(ka)t");
define("DBVLAN_15", "Ellenőrzés indítása");
define("DBVLAN_16", "Adatbázis ellenőrzés");

define("DBVLAN_19", "Javítás megkísérlése");

define("DBVLAN_21", "Kijelöltek javítása");
define("DBVLAN_22", "[x] nem olvasható");
define("DBVLAN_23", "Adatbázis programok");
define("DBVLAN_24", "Válaszd ki műveletet.");
define("DBVLAN_25", "Index hiányzik!");
define("DBVLAN_26", "[x] tábla hibás.");
