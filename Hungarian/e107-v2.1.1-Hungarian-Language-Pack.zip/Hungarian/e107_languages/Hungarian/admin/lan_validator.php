<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_VALIDATE_0",   "Ismeretlen hiba");
define("LAN_VALIDATE_101", "Hiányzó érték");
define("LAN_VALIDATE_102", "Nem várt érték típus");
define("LAN_VALIDATE_103", "Érvénytelen karakter");
define("LAN_VALIDATE_104", "Érvénytelen email cím");
define("LAN_VALIDATE_105", "Mezők nem egyeznek" );
define("LAN_VALIDATE_131", "A karakterlánc túl rövid");
define("LAN_VALIDATE_132", "A karakterlánc túl hosszú");
define("LAN_VALIDATE_133", "A szám túl alacsony");
define("LAN_VALIDATE_134", "A szám túl magas");
define("LAN_VALIDATE_135", "A tömb szám túl alacsony");
define("LAN_VALIDATE_136", "A tömb szám túl magas");
define("LAN_VALIDATE_151", "Egész szám szükséges");
define("LAN_VALIDATE_152", "Float szám szükséges");
define("LAN_VALIDATE_153", "Példány típus szükséges");
define("LAN_VALIDATE_154", "Tömb típus szükséges");
define("LAN_VALIDATE_191", "Üres érték");
define("LAN_VALIDATE_201", "Fájl nem létezik");
define("LAN_VALIDATE_202", "Fájl nem írható");
define("LAN_VALIDATE_203", "Fájl túllépte a megengedett fájl méretet");
define("LAN_VALIDATE_204", "Fájl méret kicsebb, mint a megengedett minimális fájl méret");

define("LAN_VALIDATE_FAILMSG", "[x] hitelesítési hiba: [y] [z].");
