<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Hungarian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/02/22 13:10:41
|
|        $Author: Yesszus $
+---------------------------------------------------------------+
*/

define("FRTLAN_13", "Kezdőlap beállításai");
define("FRTLAN_30", "Egyéni oldalak");
define("FRTLAN_35", "Bejelentkezés utáni oldal");
define("FRTLAN_42", "Új szabály hozzáadása");
define("FRTLAN_43", "Csoport");
define("FRTLAN_46", "Meglévő szabály módosítása");
define("FRTLAN_49", "Kezdőlap");
define("FRTLAN_51", "Egyéb");
define("FRTLAN_PAGE_TITLE", "Kezdőlap");
define("FRTLAN_56", "duplikált definíció ehhez a csoporthoz:");
define("FRTLAN_57", "Szoftver hiba");
define("FRTLAN_61", "Kiválasztás");


?>