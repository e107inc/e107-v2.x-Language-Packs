<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_DOCS", "Rendszer Dokumentáció");
define("LAN_DOCS_SECTIONS", "Részek");
define("LAN_DOCS_GOTOP", "Tetejére");
define("LAN_DOCS_ANSWER", "Válasz");
define("LAN_DOCS_QUESTION", "Kérdés");
