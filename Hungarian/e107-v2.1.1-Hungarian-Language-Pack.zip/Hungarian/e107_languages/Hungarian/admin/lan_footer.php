<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("FOOTLAN_1", "Weboldal");
define("FOOTLAN_2", "Főadmin");
define("FOOTLAN_3", "Verzió");
define("FOOTLAN_4", "alverzió");
define("FOOTLAN_5", "Adminisztrációs sablon");
define("FOOTLAN_6", "-");
define("FOOTLAN_7", "Információ");
define("FOOTLAN_8", "Telepítés dátuma");
define("FOOTLAN_9", "Szerver");
define("FOOTLAN_10", "kiszolgáló");
define("FOOTLAN_11", "PHP Verzió");
define("FOOTLAN_12", "MySQL");
define("FOOTLAN_13", "Weboldal Info");
define("FOOTLAN_14", "Dokumentáció megtekintése");
define("FOOTLAN_15", "Dokumentáció");
define("FOOTLAN_16", "Adatbázis");
define("FOOTLAN_17", "Karakterkészlet");
define("FOOTLAN_18", "Sablon");
define("FOOTLAN_19", "Szerver Idő");
define("FOOTLAN_20", "Biztonsági szint");
