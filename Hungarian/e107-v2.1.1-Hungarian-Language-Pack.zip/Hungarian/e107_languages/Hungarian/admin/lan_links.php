<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LCLAN_15", "Link neve");
define("LCLAN_19", "Megnyitás módja");
define("LCLAN_20", "Azonos ablakban");
define("LCLAN_23", "Új ablakban");
define("LCLAN_24", "600x400 ablakban");
define("LCLAN_78", "Leírás mutatása súgóként");
define("LCLAN_79", "A leírás akkor fog megjelenni, amikor az egér a link fölé ér");
define("LCLAN_80", "Kinyitható almenük aktiválása");
define("LCLAN_81", "Az almenük a szülőjükre kattintás után lesznek láthatóak. (A link szülő letiltva)");

define("LCLAN_104", "Allink ehhez");
define("LCLAN_105", "Funkció");
define("LCLAN_106", "Tulajdona");
define("LCLAN_107", "URL felülírásának engedélyezése egy dinamikusan létrehozott Keresőbarát URL-el");
define("LCLAN_108", "Néhány beállítás kihagyva - nem tudod kiválasztani a Linket, mint allink, mely az adott az allinkhez kapcsolódikk.");
define("LCLAN_109", "Válassz egy kezdőt (szülőt)");
define("LCLAN_110", "Válassz ki egy generátor modult");
define("LCLAN_111", "Nincs érvényes generátor modul adat");

define("LINKLAN_1", "Megnyitás 800x600-as ablakban");
define("LINKLAN_4", "Allink Generátor");
define("LINKLAN_5", "Allinkek generálása");
define("LINKLAN_6", "Allink létrehozása ebből");
define("LINKLAN_7", "Melyik link alá készítsen allinket?");
define("LINKLAN_8", "Hír kategóriák");
define("LINKLAN_9", "Letöltés kategóriák");
