<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("UDALAN_1", "Hiba - küldd el újra.");
define("UDALAN_2", "Beállítások frissítve");
define("UDALAN_3", "Beállítások frissítve:");
define("UDALAN_4", "Név");
define("UDALAN_6", "Jelszó megerősítése");
define("UDALAN_7", "Jelszó módosítása");
define("UDALAN_8", "Jelszó módosítása:");
