<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Hungarian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/04/22 13:08:21
|
|        $Author: Yesszus $
+---------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "A nyelvezet beállításával megadható az oldal alapértelmezett nyelvezete, valamint a segítségével akár többnyelvű tartalom is létrehozható. A nyelvi eszközök menüpont alatt lehetőség nyílik a jelenleg használt nyelvi fájlok ellenőrzésére és módosítására is.";
$ns -> tablerender("Nyelv Súgó", $text);
