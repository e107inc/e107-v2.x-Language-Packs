<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Hungarian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/04/22 13:08:21
|
|        $Author: Yesszus $
+---------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Itt kezelhetjük a weboldalon megjelenő üdvözlő üzeneteket, amelyeket aktiválhatunk és kikapcsolhatunk. Üzeneteket jeleníthet meg a vendégek, regisztrált / bejelentkezett tagok, moderátorok és az adminok számára.";
$ns -> tablerender("Üdvözlő Üzenet", $text);
