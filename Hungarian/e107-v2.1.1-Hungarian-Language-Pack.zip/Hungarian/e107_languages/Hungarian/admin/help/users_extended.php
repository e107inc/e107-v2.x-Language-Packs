<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Hungarian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/04/22 13:08:21
|
|        $Author: Yesszus $
+---------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = " A bővített felhasználói mezők segítségével lehetőség nyílik további felhasználói adatokat tartalmazó mezők létrehozására, amelyek a tag profil oldalán az 'Egyéb' információknál fognak megjelenni.";
$ns -> tablerender(" Bővített felhasználói mezők Súgó", $text);