<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Hungarian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/04/22 13:08:21
|
|        $Author: Yesszus $
+---------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Admin súgó";
$text = "Itt hozhatsz létre új adminisztrátorokat, törölheted a meglévőket. Az adminisztrátorok csak azokkal a jogokkal fognak rendelkezni, amiket itt beállítasz.<br /><br />
Új admin létrehozásához lépj a Felhasználók oldalra és írd felül a meglévő Tag admin státuszát.";
$ns -> tablerender($caption, $text);
