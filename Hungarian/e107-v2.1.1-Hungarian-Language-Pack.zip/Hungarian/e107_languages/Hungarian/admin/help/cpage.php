<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Hungarian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/04/22 13:08:21
|
|        $Author: Yesszus $
+---------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Itt lehet létrehozni saját menüket és oldalakat, bármilyen tartalommal<br /><br />";

$ns -> tablerender('Saját Menük/Oldalak Súgó', $text);
