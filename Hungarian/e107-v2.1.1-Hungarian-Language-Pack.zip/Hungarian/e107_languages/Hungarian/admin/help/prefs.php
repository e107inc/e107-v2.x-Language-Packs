<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Hungarian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/04/22 13:08:21
|
|        $Author: Yesszus $
+---------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "A beállítások oldalon megadható a webhelyre vonatkozó összes fontos információ, a webhely nevétől és leírásától kezdve a flood védelemig és a káromkodás szűrésig.";
$ns -> tablerender("Beállítások Súgó", $text);
