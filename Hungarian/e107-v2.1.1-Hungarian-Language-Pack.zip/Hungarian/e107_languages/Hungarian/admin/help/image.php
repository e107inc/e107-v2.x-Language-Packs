<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Hungarian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/04/22 13:08:21
|
|        $Author: Yesszus $
+---------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Ezen az oldalon lehet engedélyezni, vagy tiltani, hogy a tagok képeket helyezzenek el a hozzászólásaikban és hogy mely csoport tagjai tekinthetik meg ezeket a képeket. Kiválasztható a kép átméretezési eljárás, valamint ellenőrizhetőek a feltöltött avatarok.";
$ns -> tablerender("Képek Súgó", $text);
