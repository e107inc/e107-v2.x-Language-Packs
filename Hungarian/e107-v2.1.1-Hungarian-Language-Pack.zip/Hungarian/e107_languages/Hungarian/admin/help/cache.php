<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Hungarian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/04/22 13:08:21
|
|        $Author: Yesszus $
+---------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Cache súgó";
$text = "A cachelés bekapcsolása nagymértékben gyorsítja az oldalak elérését, és minimalizálja az adatbázis lekérdezéseket.<br /><br /><b>FONTOS! Ha épp a saját témádat készíted, akkor kapcsold ki, mert a változtatások nem fognak látszani.</b>";
$ns -> tablerender($caption, $text);