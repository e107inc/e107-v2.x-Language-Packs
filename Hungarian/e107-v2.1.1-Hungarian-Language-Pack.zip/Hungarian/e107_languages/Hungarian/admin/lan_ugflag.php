<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("UGFLAN_2", "Bekapcsolás");
define("UGFLAN_4", "Karbantartási beállítások");

define("UGFLAN_5", "Karbantartási üzenet");
define("UGFLAN_6", "Hagyd üresen az alapértelmezett üzenet megjelenítéséhez");
define("UGFLAN_8", "Hozzáférés csak Adminok részére");
define("UGFLAN_9", "Hozzáférés csak Főadmin részére");
