<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("METLAN_00", "Meta Tag-ek");

define("METLAN_1", "További meta Tag-ek");
define("METLAN_2", "Pl.: < meta name='revisit-after' content='30 days' />");
define("METLAN_3", "Használd a Hírek címét és az összegzést, mint eegy meta-leírás a Hírek oldalon.");
