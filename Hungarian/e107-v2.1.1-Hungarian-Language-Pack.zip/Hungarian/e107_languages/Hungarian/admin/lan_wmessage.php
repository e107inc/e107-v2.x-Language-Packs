<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("WMLAN_00","Üdvözlő Üzenet");
define("WMLAN_02","Üzenet");
define("WMLAN_04","Üzenet szövege");

define("WMLAN_05","Keret");
define("WMLAN_06","Jelöld be, ha szeretnéd, hogy az üzenet a weboldal sminkjének stílusában jelenjen meg");
define("WMLAN_07","Az alaprendszer felülírása a {WMESSAGE} shortcode használatához:");

define("WMLAN_09","Nincsenek üdvözlő üzenetek");
define("WMLAN_10","Üzenet Fejléc");
