<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("ONLINE_EL1", "Vendégek: ");
define("ONLINE_EL2", "Tagok: ");
define("ONLINE_EL3", "Ezen az oldalon: ");
define("ONLINE_EL4", "Jelenleg");
define("ONLINE_EL5", "Tagok");
define("ONLINE_EL6", "Új tagok");
define("ONLINE_EL7", "nézi");
define("ONLINE_EL8", "Legtöbb: ");
define("ONLINE_EL9", "-");
define("ONLINE_EL10", "Felhasználónév");
define("ONLINE_EL11", "nézi");
define("ONLINE_EL12", "Válasz");
define("ONLINE_EL13", "Fórum");
define("ONLINE_EL14", "Téma");
define("ONLINE_EL15", "Oldal");
define("ONLINE_EL16", "Nincs elérhető információ");

define("CLASSRESTRICTED", "Felhasználói csoporthoz kötött oldal!");
define("CHAT", "Társalgás");
define("DOWNLOAD", "Letöltések");
define("EMAIL", "Levelezés");
define("FORUM", "Fórum főoldal");
define("LINKS", "Linkek");
define("NEWS", "Hírek");
define("OLDPOLLS", "Régebbi szavazások");
define("POLLCOMMENT", "Szavazás");
define("PRINTPAGE", "Nyomtatás");
define("LOGIN", "Bejelentkezés");
define("SEARCH", "Keresés");
define("STATS", "Weblap statisztika");
define("SUBMITNEWS", "Hír beküldése");
define("UPLOAD", "Feltöltések");
define("USERPAGE", "Profil");
define("USERSETTINGS", "Beállítások");
define("ONLINE", "Jelenlegi felhasználók");
define("LISTNEW", "Újdonság lista");
define("USERPOSTS", "Üzenetek");
define("SUBCONTENT", "Tartalom beküldése");
define("TOP", "Top Üzenetek/Legaktívabb témák");
define("ADMINAREA", "Admin terület");
define("BUGTRACKER", "Hibakövetés");
define("EVENT", "Esemény lista");
define("CALENDAR", "Eseménynaptár");
define("FAQ", "GYIK");
define("PM", "Privát Üzenetek");
define("SURVEY", "Szavazás");
define("ARTICLE", "Hír");
define("CONTENT", "Tartalom oldal");
define("REVIEW", "Ismertetés");
define("OTHER", "Egyéb oldal: ");
