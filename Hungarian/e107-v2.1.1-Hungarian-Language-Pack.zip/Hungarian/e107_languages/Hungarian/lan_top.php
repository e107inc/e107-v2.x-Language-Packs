<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("TOP_LAN_0", "A legtöbb fórumbejegyzést író");
define("TOP_LAN_1", "Felhasználónév");
define("TOP_LAN_2", "Bejegyzések");
define("TOP_LAN_3", "A legtöbb hozzászólást író");
define("TOP_LAN_5", "A legtöbb chatbox üzenetet író");
define("TOP_LAN_6", "Oldal-értékelés");

define("LAN_1", "Téma");
define("LAN_2", "Beküldő");
define("LAN_3", "Megtekintés");
define("LAN_4", "Válaszok");
define("LAN_5", "Utolsó bejegyzés");
define("LAN_6", "Témák");
define("LAN_7", "Legaktívabb témák");
define("LAN_8", "Legtöbb bejegyzést író");
