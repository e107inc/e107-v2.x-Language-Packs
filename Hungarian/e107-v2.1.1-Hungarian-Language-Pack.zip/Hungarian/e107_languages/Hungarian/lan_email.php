<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_EMAIL_1", "Feladó:");
define("LAN_EMAIL_2", "A feladó IP-címe:");
define("LAN_EMAIL_3", "Email innen lett küldve: ");
define("LAN_EMAIL_4", "Email küldése");
define("LAN_EMAIL_5", "Email küldése egy ismerősnek");
define("LAN_EMAIL_6", "Úgy gondolom téged érdekelne ez a bejegyzés...");
define("LAN_EMAIL_7", "email küldése valakinek");
define("LAN_EMAIL_8", "Hozzászólás");
define("LAN_EMAIL_9", "Sajnálom - de nem sikerült elküldeni az emailt");
define("LAN_EMAIL_10", "Az email el lett küldve neki:");
define("LAN_EMAIL_11", "Az email el lett küldve");
define("LAN_EMAIL_13", "Cikk elküldése email-ben egy ismerősnek");
define("LAN_EMAIL_14", "Hír elküldése email-ben egy ismerősnek");
define("LAN_EMAIL_15", "Felhasználónév: ");
define("LAN_EMAIL_106", "A megadott email cím nem tűnik valósnak");
define("LAN_EMAIL_185", "Cikk küldése");
define("LAN_EMAIL_186", "Hír küldése");
define("LAN_EMAIL_187", "Címzett e-mail címe");
define("LAN_EMAIL_188", "Úgy gondolom téged érdekelne ez a hír...");
define("LAN_EMAIL_189", "Úgy gondolom téged érdekelne ez a cikk...");
define("LAN_EMAIL_190", "Írd be a látható kódot");
