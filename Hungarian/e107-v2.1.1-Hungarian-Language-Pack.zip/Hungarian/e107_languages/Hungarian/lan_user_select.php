<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("US_LAN_1", "Felhasználó kiválasztása");
define("US_LAN_2", "Felhasználó csoport kiválasztása");
define("US_LAN_3", "Összes felhasználó");
define("US_LAN_4", "Felhasználónév keresése");
define("US_LAN_5", "Felhasználói találat(ok)");
define("US_LAN_6", "Keresés");
