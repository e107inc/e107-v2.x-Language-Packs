<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LANDT_01", "éve");
define("LANDT_02", "hónapja");
define("LANDT_03", "hete");
define("LANDT_04", "napja");
define("LANDT_05", "órája");
define("LANDT_06", "perce");
define("LANDT_07", "másodperce");
define("LANDT_01s", "éve");
define("LANDT_02s", "hónapja");
define("LANDT_03s", "hete");
define("LANDT_04s", "napja");
define("LANDT_05s", "órája");
define("LANDT_06s", "perce");
define("LANDT_07s", "másodperce");

define("LANDT_08", "perce");
define("LANDT_08s", "perce");
define("LANDT_09", "m-perce");
define("LANDT_09s", "m-perce");
define("LANDT_AGO", ".");
