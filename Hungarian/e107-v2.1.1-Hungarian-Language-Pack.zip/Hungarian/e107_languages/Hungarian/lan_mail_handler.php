<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LANMAILH_1", "Az e107 CMS által létrehozva");
define("LANMAILH_2", "Ez egy 'multi-part' üzenet MIME-formátumban.");
define("LANMAILH_3", " nincs rendesen megformázva");
define("LANMAILH_4", "A kiszolgáló elutasította a címet");
define("LANMAILH_5", "Nem érkezett válasz a kiszolgálótól");
define("LANMAILH_6", "Nem található E-mail kiszolgáló.");
define("LANMAILH_7", " érvényesnek tűnik.");
