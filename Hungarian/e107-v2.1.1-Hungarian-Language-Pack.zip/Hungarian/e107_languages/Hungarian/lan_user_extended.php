<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Hungarian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/04/09 11:35:38
|
|        $Author: Yesszus $
+---------------------------------------------------------------+
*/

define("UE_LAN_1", "Szövegmező");
define("UE_LAN_2", "Rádiógombok");
define("UE_LAN_3", "Lenyíló menü");
define("UE_LAN_4", "Adatbázis tábla mező");
define("UE_LAN_5", "Szövegmező");
define("UE_LAN_6", "Egész");
define("UE_LAN_8", "Nyelv");
define("UE_LAN_9", "Előre definiált lista");
define("UE_LAN_10", "Jelölő négyzet");
define("UE_LAN_21", "Név");
define("UE_LAN_22", "Típus");
define("UE_LAN_23", "Használatban");
define("UE_LAN_HIDE", "Elrejtés");
define("UE_LAN_LOCATION", "Lakóhely");
define("UE_LAN_LOCATION_DESC", "Felhasználó lakóhelye");
define("UE_LAN_AIM", "AIM Cím");
define("UE_LAN_AIM_DESC", "AIM Cím");
define("UE_LAN_ICQ", "ICQ Szám");
define("UE_LAN_ICQ_DESC", "ICQ Szám");
define("UE_LAN_YAHOO", "Yahoo! Cím");
define("UE_LAN_YAHOO_DESC", "Yahoo! Cím");
define("UE_LAN_MSN", "MSN Cím");
define("UE_LAN_MSN_DESC", "MSN Cím");
define("UE_LAN_HOMEPAGE", "Weboldal");
define("UE_LAN_HOMEPAGE_DESC", "Felhasználó weboldala (url)");
define("UE_LAN_BIRTHDAY", "Születésnap");
define("UE_LAN_BIRTHDAY_DESC", "Születésnap");
define("UE_LAN_LANGUAGE", "Nyelv");
define("UE_LAN_LANGUAGE_DESC", "Felhasználó nyelve");
define("UE_LAN_COUNTRY", "Ország");
define("UE_LAN_COUNTRY_DESC", "Felhasználó országa (db tábla hozzárendelés)");
define("UE_LAN_TIMEZONE", "Időzóna");
define("UE_LAN_TIMEZONE_DESC", "Felhasználó időzónája (az előre meghatározott listából)");
define("LAN_UE_FAIL_HOMEPAGE", "Érvénytelen bejegyzés a főoldal beállításaihoz");
define("UE_LAN_SKYPE", "Skype Cím");
define("UE_LAN_SKYPE_DESC", "Skype Cím");
define("UE_LAN_GENDER", "Neme");
define("UE_LAN_GENDER_DESC", "Neme");
define("UE_LAN_MALE", "Férfi");
define("UE_LAN_FEMALE", "Nő");
define("UE_LAN_COMMENT", "Hozzászólások");
define("UE_LAN_COMMENT_DESC", "Hozzászólás Doboz");


?>