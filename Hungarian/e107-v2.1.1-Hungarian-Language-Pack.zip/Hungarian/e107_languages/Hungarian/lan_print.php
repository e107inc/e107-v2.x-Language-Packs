<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Nyomtatóbarát változat"); }

define("LAN_PRINT_86", "Kategória:");
define("LAN_PRINT_87", "Írta: ");
define("LAN_PRINT_94", "Beküldte: ");
define("LAN_PRINT_135", "Hír: ");
define("LAN_PRINT_303", "A hír megtalálható itt: ");
define("LAN_PRINT_305", "Alcím: ");
define("LAN_PRINT_306", "A hír megtalálható itt: ");
define("LAN_PRINT_307", "Oldal nyomtatása");

define("LAN_PRINT_1", "Nyomtatóbarát változat");
