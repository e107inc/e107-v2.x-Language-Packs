<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("NP_1", "Előző oldal");
define("NP_2", "Következő oldal");

define("LAN_NP_FIRST", "Első");
define("LAN_NP_URLFIRST", "Ugrás az első oldalra");
define("LAN_NP_PREVIOUS", "Előző");
define("LAN_NP_URLPREVIOUS", "Ugrás az előző oldalra");
define("LAN_NP_NEXT", "Következő");
define("LAN_NP_URLNEXT", "Ugrás a következő oldalra");
define("LAN_NP_LAST", "Utolsó");
define("LAN_NP_URLLAST", "Ugrás az utolsó oldalra");
define("LAN_NP_GOTO", "Ugrás az [x] oldalra");
define("LAN_NP_URLCURRENT", "Aktuális oldal");

define("NP_CAPTION", "[x]. oldal. Összes oldal: [y]");
