<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("RATELAN_0", "szavazat");
define("RATELAN_1", "szavazat");
define("RATELAN_2", "Hogyan értékeled?");
define("RATELAN_3", "Köszönjük az értékelést!");
define("RATELAN_4", "Nincs értékelve");
define("RATELAN_5", "Értékelés:");
define("RATELAN_6", "Az értékeléshez be kell jelentkezned.");

define("RATELAN_POOR", "Elég gyenge!");
define("RATELAN_FAIR", "Hmmm, elmegy!");
define("RATELAN_GOOD", "Egész jó!");
define("RATELAN_VERYGOOD", "Nagyon jó!");
define("RATELAN_EXCELLENT", "Wow, kitűnő!");
