<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("PAGE_NAME", "Felhasználói bejegyzések");

define("UP_LAN_0", "Összes fórumbejegyzése ");
define("UP_LAN_1", "Összes hozzászólása ");
define("UP_LAN_2", "Téma");
define("UP_LAN_3", "Megtekintések");
define("UP_LAN_4", "Válaszok");
define("UP_LAN_5", "Utolsó bejegyzés");
define("UP_LAN_6", "Témák");
define("UP_LAN_7", "Nincs hozzászólás");
define("UP_LAN_8", "Nincs bejegyzés");
define("UP_LAN_9", " - ");
define("UP_LAN_10", "Válasz");
define("UP_LAN_11", "Írta: ");
define("UP_LAN_12", "Keresés");
define("UP_LAN_14", "Fórum bejegyzések");
define("UP_LAN_15", "Válasz");
define("UP_LAN_16", "IP Cím");
