<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("NT_LAN_US_1", "Felhasználói regisztráció");

define("NT_LAN_UV_1", "Felhasználói regisztráció jóváhagyva");
define("NT_LAN_UV_2", "Felhasználó ID: ");
define("NT_LAN_UV_3", "Felhasználó Bejelentkező Név: ");
define("NT_LAN_UV_4", "Felhasználó IP: ");


define("NT_LAN_LI_1", "Felhasználói bejelentkezés");

define("NT_LAN_LO_1", "Felhasználói kijelentkezés");
define("NT_LAN_LO_2", " kijelentkezett az oldalról");

define("NT_LAN_FL_1", "Kitiltás");
define("NT_LAN_FL_2", "Kitiltott IP cím");

define("NT_LAN_SN_1", "Beküldött hír");

define("NT_LAN_ML_1", "Tömeges email küldés kész!");

define("NT_LAN_NU_1", "Frissítve!");

define("NT_LAN_ND_1", "A hír törölve!");
define("NT_LAN_ND_2", "Törölt hír ID");
