<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("PAGE_NAME", "Az oldal átmenetileg zárva");
define("LAN_SITEDOWN_00", "átmenetileg zárva");
define("LAN_SITEDOWN_01", "Karbantartás miatt az oldalt átmenetileg lezártuk. Remélhetőleg nem tart sokáig - látogasson vissza később. Elnézést kérünk a kellemetlenségért.");
