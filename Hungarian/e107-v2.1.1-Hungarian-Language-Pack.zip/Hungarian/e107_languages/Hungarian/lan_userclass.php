<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("UC_LAN_0", "Mindenki (Publikus)");
define("UC_LAN_1", "Vendégek");
define("UC_LAN_2", "Senki (inaktív)");
define("UC_LAN_3", "Tagok");
define("UC_LAN_4", "Csak olvasási jog");
define("UC_LAN_5", "Adminisztrátor");
define("UC_LAN_6", "Főadminisztrátor");
define("UC_LAN_7", "Fórum Moderátorok");
define("UC_LAN_8","Adminok és Moderátorok");
define("UC_LAN_9","Új Tagok");
define("UC_LAN_10", "Kereső Robotok");
define("UC_LAN_INVERT", "Nem --CLASS--");
define("UC_LAN_INVERTLABEL", "Mindenki, kivéve..");
