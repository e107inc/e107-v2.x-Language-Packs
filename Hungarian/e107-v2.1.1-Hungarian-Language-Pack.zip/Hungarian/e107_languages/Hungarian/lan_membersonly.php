<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("PAGE_NAME", "Csak regisztrált felhasználóknak");

define("LAN_MEMBERS_0", "korlátozott terület");
define("LAN_MEMBERS_1", "Ez egy korlátozott terület.");
define("LAN_MEMBERS_2", "A hozzáféréshez kérlek [jelentkezz be]");
define("LAN_MEMBERS_3", "vagy [regisztrálj] egy felhasználói fiókot.");
define("LAN_MEMBERS_4", "A főoldalra történő átirányításhoz kattints ide.");
