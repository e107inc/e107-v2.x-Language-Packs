<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_SITELINKS_183", "Főmenü");
define("LAN_SITELINKS_502", "Admin terület");
