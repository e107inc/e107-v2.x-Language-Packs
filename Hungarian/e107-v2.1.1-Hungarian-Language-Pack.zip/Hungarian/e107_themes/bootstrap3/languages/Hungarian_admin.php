<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Hungarian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/05/06 12:21:54
|
|        $Author: Yesszus $
+---------------------------------------------------------------+
*/

define("LAN_THEMEPREF_00", "Logó");
define("LAN_THEMEPREF_01", "Megjelenítés");
define("LAN_THEMEPREF_02", "Regisztráció/Bejelentkezési Terület");
define("LAN_THEMEPREF_03", "Bootswatch Stilus");
define("LAN_THEMEPREF_04", "Oldal Neve");
define("LAN_THEMEPREF_05", "Logó");
define("LAN_THEMEPREF_06", "Logó &amp; Oldal Név");
define("LAN_THEMEPREF_07", "balra");
define("LAN_THEMEPREF_08", "jobbra");
define("LAN_THEMEPREF_09", "felül");
define("LAN_THEMEPREF_10", "alul");


?>