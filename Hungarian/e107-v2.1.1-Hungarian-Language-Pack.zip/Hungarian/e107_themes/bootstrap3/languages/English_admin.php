<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - 
|

+----------------------------------------------------------------------------+
*/

define("LAN_THEMEPREF_00", "Branding:");
define("LAN_THEMEPREF_01", "Navbar Alignment:");
define("LAN_THEMEPREF_02", "Signup/Login Placement:");
define("LAN_THEMEPREF_03", "Bootswatch Styles:");
define("LAN_THEMEPREF_04", "Site Name");
define("LAN_THEMEPREF_05", "Logo");
define("LAN_THEMEPREF_06", "Logo &amp; Site Name");
define("LAN_THEMEPREF_07", "left");
define("LAN_THEMEPREF_08", "right");
define("LAN_THEMEPREF_09", "top");
define("LAN_THEMEPREF_10", "bottom");
 

?>